/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package searchstudent;

import static org.junit.Assert.*;
import org.junit.Test;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;

public class StudentTest {

    @Test
    public void testSaveStudent() {
        String input = "123\nJohn Doe\n18\njohndoe@example.com\nMath\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        Student.SaveStudent();

        assertEquals(1, Student.students.size());
        StudentOne student = Student.students.get(0);

        assertEquals(123, student.getId());
        assertEquals("John Doe", student.getName());
        assertEquals(18, student.getAge());
        assertEquals("johndoe@example.com", student.getEmail());
        assertEquals("Math", student.getCourse());
    }

    @Test
    public void testSearchStudent() {
        ArrayList<StudentOne> students = new ArrayList<>();
        StudentOne student = new StudentOne(123, "John Doe", 18, "johndoe@example.com", "Math");
        students.add(student);
        Student.students = students;

        String input = "123\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        Student.SearchStudent();
    }

    @Test
    public void testDeleteStudent() {
        ArrayList<StudentOne> students = new ArrayList<>();
        StudentOne student = new StudentOne(123, "John Doe", 18, "johndoe@example.com", "Math");
        students.add(student);
        Student.students = students;

        String input = "123\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        Student.DeleteStudent();

        assertEquals(0, Student.students.size());
    }

    @Test
    public void testStudentReport() {
        ArrayList<StudentOne> students = new ArrayList<>();
        StudentOne student = new StudentOne(123, "John Doe", 18, "johndoe@example.com", "Math");
        students.add(student);
        Student.students = students;

        Student.StudentReport();
    }

    // No need to test ExitStudentApplication() as it immediately exits the program.
}
