
package searchstudent;

import java.util.Scanner;

public class SearchStudent {
   
    public static void main(String[] args) {
        
        Scanner kb = new Scanner(System.in);

        while (true) {
            System.out.println("STUDENT MANAGMENT APPLICATION");
            System.out.println("***********************************************");
            System.out.println("Enter 1 to launch a menu, or any other key to exit:");
            int choice = kb.nextInt();

            if (choice == 1) {
                System.out.println("Please select one of the following menu items:");
                System.out.println("1. Capture a new student");
                System.out.println("2. Search for a student");
                System.out.println("3. Delete a student");
                System.out.println("4. Print student report");
                System.out.println("5. Exit application");

                int menuChoice = kb.nextInt();
                switch (menuChoice) {
                    case 1:
                        Student.SaveStudent();
                        break;
                    case 2:
                        Student.SearchStudent();
                        break;
                    case 3:
                        Student.DeleteStudent();
                        break;
                    case 4:
                        Student.StudentReport();
                        break;
                    case 5:
                        Student.ExitStudentApplication();
                        break;
                    default:
                        System.out.println("Invalid menu choice. Please try again.");
                        break;
                }
            } else {
                break;
            }      }
        }
    }

        
