
package searchstudent;


import java.util.ArrayList;
import java.util.Scanner;

class Student {
    
    static ArrayList<StudentOne> students = new ArrayList<>();

    public static void SaveStudent() {
        Scanner kb = new Scanner(System.in);
        
        System.out.print("CAPTURE A NEW STUDENT \n");
        System.out.println("*****************************");

        System.out.println("Enter student ID: ");
        int id = kb.nextInt();
        kb.nextLine();  // Consume the newline character

        System.out.println("Enter student name: ");
        String name = kb.nextLine();

        int age;
        do {
            System.out.println("Enter student age (>= 16): ");
            age = kb.nextInt();
        } while (age < 16);

        kb.nextLine();  

        System.out.println("Enter student email: ");
        String email = kb.nextLine();

        System.out.println("Enter student course: ");
        String course = kb.nextLine();

        StudentOne student = new StudentOne(id, name, age, email, course);
        students.add(student);

        System.out.println("Student details successfully saved.");
    }

    public static void SearchStudent() {
        Scanner kb = new Scanner(System.in);

        System.out.println("Enter student ID to search: ");
        int searchId = kb.nextInt();

        boolean found = false;
        for (StudentOne student : students) {
            if (student.getId() == searchId) {
                System.out.println("-------------------------------------");
                System.out.println("ID: " + student.getId());
                System.out.println("Name: " + student.getName());
                System.out.println("Age: " + student.getAge());
                System.out.println("Email: " + student.getEmail());
                System.out.println("Course: " + student.getCourse());
                System.out.println("-------------------------------------");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("----------------------------");
            System.out.println("Student not found.");
            System.out.println("----------------------------");
        }
    }

    public static void DeleteStudent() {
        Scanner kb = new Scanner(System.in);

        System.out.println("Enter student ID to delete: ");
        int deleteId = kb.nextInt();

        boolean deleted = false;
        for (StudentOne student : students) {
            if (student.getId() == deleteId) {
                students.remove(student);
                System.out.println("Student " + student.getId() + " successfully deleted.");
                deleted = true;
                break;
            }
        }

        if (!deleted) {
            System.out.println("Student not found.");
        }
    }

    public static void StudentReport() {
        System.out.println("Student Report:");
        for (StudentOne student : students) {
            
            System.out.println("Student: " + student.getName());
            System.out.println("------------------------------------" );
            System.out.println("Student ID: " + student.getId());
            System.out.println("Student Name: " + student.getName());
            System.out.println("Student Age: " + student.getAge());
            System.out.println("Student Email: " + student.getEmail());
            System.out.println("Student Course: " + student.getCourse());
            System.out.println("------------------------------------" );
            System.out.println();
        }
    }

    public static void ExitStudentApplication() {
        System.exit(0);
    }
}
