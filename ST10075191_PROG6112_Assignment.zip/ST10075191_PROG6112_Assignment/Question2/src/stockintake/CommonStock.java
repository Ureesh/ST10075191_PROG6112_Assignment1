/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockintake;

/**
 *
 * @author urees
 */
class CommonStock extends Stock {
    public CommonStock(String symbol, double price, int quantity) {
        super(symbol, price, quantity);
    }
}
