/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockintake;

/**
 *
 * @author urees
 */
class PreferredStock extends Stock {
    private double dividendRate;

    public PreferredStock(String symbol, double price, int quantity, double dividendRate) {
        super(symbol, price, quantity);
        this.dividendRate = dividendRate;
    }

    @Override
    public double getValue() {
        return (price * quantity) + (dividendRate * quantity);
    }
}
