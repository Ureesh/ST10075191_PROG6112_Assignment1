/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockintake;

/**
 *
 * @author urees
 */
class Stock {
    protected String symbol;
    protected double price;
    protected int quantity;

    public Stock(String symbol, double price, int quantity) {
        this.symbol = symbol;
        this.price = price;
        this.quantity = quantity;
    }

    public double getValue() {
        return price * quantity;
    }
    
    public void displayDetails() {
    System.out.println("Symbol: " + symbol);
    System.out.println("Price per unit: $" + price);
    System.out.println("Quantity: " + quantity);
    System.out.println("Value: $" + getValue());
}
}

