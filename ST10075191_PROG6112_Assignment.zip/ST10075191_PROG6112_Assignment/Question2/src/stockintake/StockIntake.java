/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockintake;

import java.util.Scanner;

/**
 *
 * @author urees
 */
public class StockIntake {

    /**
     * @param args the command line arguments
     */
    
    private static Stock[] stocks;
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        boolean exitFlag = false;
        while (!exitFlag)
        {
            System.out.println("Please Select an option.");
        System.out.println("1 : Add stock.\n"
                + "2: View report.\n"
                + "3: Exit");
        int selection = kb.nextInt();
        
        switch(selection)
        {case 1: stockIntake(); break;
        case 2: generateReport(); break;
        case 3: exitFlag = true; System.exit(0); break;
        default: System.out.println("Invalid option selected."); break;
        
        }
        }
        

        
    }
    
    public static void stockIntake()
    {
        Scanner kb = new Scanner(System.in);

        int numStocks;
        System.out.print("Enter the number of stocks: ");
        numStocks = kb.nextInt();
        stocks = new Stock[numStocks]; // Initialize the array

        

        for (int i = 0; i < numStocks; i++) {
            System.out.println("\nStock " + (i + 1));
            System.out.print("Enter the symbol: ");
            String symbol = kb.next();
            System.out.print("Enter the price per unit: ");
            double price = kb.nextDouble();
            System.out.print("Enter the quantity: ");
            int quantity = kb.nextInt();

            System.out.println("Is it a common stock? (yes/no): ");
            String isCommon = kb.next();

            if (isCommon.equalsIgnoreCase("yes")) {
                stocks[i] = new CommonStock(symbol, price, quantity);
            } else {
                System.out.print("Enter the dividend rate: ");
                double dividendRate = kb.nextDouble();
                stocks[i] = new PreferredStock(symbol, price, quantity, dividendRate);
            }
        }

        
    }
    
    public static void generateReport()
    {
        
        
        if (stocks == null) {
        System.out.println("No stocks available. Please add stocks first.");
        return;
    }

    System.out.println("\nStocks:");
    for (Stock stock : stocks) {
        if (stock != null) {
            stock.displayDetails(); // Assuming you have a method to display stock details
            System.out.println(); // Add a blank line for better readability
        }
    }

    double totalValue = 0;

    for (Stock stock : stocks) {
        if (stock != null) {
            totalValue += stock.getValue();
        }
    }

    System.out.println("\nTotal value of all stocks: $" + totalValue);
    }
}
    

