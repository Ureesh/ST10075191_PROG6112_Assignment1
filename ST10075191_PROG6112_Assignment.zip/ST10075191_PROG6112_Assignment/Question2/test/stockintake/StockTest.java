/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockintake;


import static org.junit.Assert.*;
import org.junit.Test;

public class StockTest {

    @Test
    public void testGetValue() {
        Stock stock = new Stock("AAPL", 150.0, 10);
        double expectedValue = 150.0 * 10;
        assertEquals(expectedValue, stock.getValue(), 0.001);
    }

    
}

